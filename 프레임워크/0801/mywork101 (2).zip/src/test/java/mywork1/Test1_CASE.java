package mywork1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Test1_CASE {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
