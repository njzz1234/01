package egovframework.example.sample.service;

public class CmsVO {

	private int cms_no;
	private String cms_nm;
	private String cms_yn;
	private String code_gubun;

	public int getCms_no() {
		return cms_no;
	}
	public void setCms_no(int cms_no) {
		this.cms_no = cms_no;
	}
	public String getCms_nm() {
		return cms_nm;
	}
	public void setCms_nm(String cms_nm) {
		this.cms_nm = cms_nm;
	}
	public String getCms_yn() {
		return cms_yn;
	}
	public void setCms_yn(String cms_yn) {
		this.cms_yn = cms_yn;
	}
	public String getCode_gubun() {
		return code_gubun;
	}
	public void setCode_gubun(String code_gubun) {
		this.code_gubun = code_gubun;
	}

}
