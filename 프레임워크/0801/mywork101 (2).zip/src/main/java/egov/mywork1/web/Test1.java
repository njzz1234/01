package egov.mywork1.web;

public class Test1 {

	public static void main(String[] args) {
		String pass1 = "123456";
		String pass2 = MyEncrypt.testMD5(pass1);
		System.out.println(pass2);
	}
}
