package egovframework.example.sample.service;

import java.util.List;

public interface CmsService {
	String insertCms(CmsVO vo) throws Exception;
	List<?> selectCmsList(SampleDefaultVO vo) throws Exception;
	int deleteCms(String cms_no) throws Exception;
	CmsVO selectCmsDetail(CmsVO vo) throws Exception;
}
