package egovframework.example.sample.web;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.example.sample.service.DeptService;
import egovframework.example.sample.service.DeptVO;
import egovframework.example.sample.service.EgovSampleService;

@Controller
public class DeptController {

		@Resource(name = "deptService")
		private DeptService deptService;
	
		@RequestMapping("/deptWrite.do")
		public String deptWrite() {
			
			return "dept/deptWrite";
		}
		@RequestMapping("/deptWriteSave.do")
		public String insertDept( DeptVO vo ) throws Exception {
			
			String result = deptService.insertDept(vo);
			if ( result == null ) {
				System.out.println("저장 okay");
			} else {
				System.out.println("저장 fail");
			}
			return "dept/deptWriteSave";
		}
	
	}

