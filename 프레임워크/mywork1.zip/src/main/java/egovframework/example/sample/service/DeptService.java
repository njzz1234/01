package egovframework.example.sample.service;

public interface DeptService {		// 추상화(명세처리)
	
	public String insertDept(DeptVO vo) throws Exception;
	
}
