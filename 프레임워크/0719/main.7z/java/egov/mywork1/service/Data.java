package egov.mywork1.service;

public @interface Data {

}
