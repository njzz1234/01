package egovframework.example.sample.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractDAO;
import org.springframework.stereotype.Repository;

import egovframework.example.sample.service.DeptVO;

@Repository("deptDAO") //impl값과 일치
public class DetpDAO extends EgovAbstractDAO { // 데이터베이스(SQL)와 연결 담당

	public String insertDept(DeptVO vo) {		
		return (String) insert("deptDAO.insertDept",vo); // id값,새로 받는 값
	}

	public List<?> selectDeptList(DeptVO vo) {		
		return list("deptDAO.selectDeptList",vo);
	}

	public int selectDeptTotal(DeptVO vo) {		
		return (int) select("deptDAO.selectDeptTotal",vo);
	}

	public int deleteDept(DeptVO vo) {
		return delete("deptDAO.deleteDept",vo);
	}

	public DeptVO selectDeptDetail(String deptno) {
		return (DeptVO) select("deptDAO.selectDeptDetail",deptno);
	}

	public int updateDept(DeptVO vo) {
		return update("deptDAO.updateDept",vo);
	}

}
