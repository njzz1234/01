package egovframework.example.sample.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.example.sample.service.DeptService;
import egovframework.example.sample.service.DeptVO;

@Service("deptService") // controller에 있는 이름과 동일 (대소문자구분)
public class DeptServiceImpl extends EgovAbstractServiceImpl 
							 implements DeptService {
	
	@Resource(name = "deptDAO") // DAO와 일치
	private DetpDAO deptDAO;
	
	@Override
	public String insertDept(DeptVO vo) throws Exception {		
		return deptDAO.insertDept(vo); // 클래스명.메소드명
	}

	@Override
	public List<?> selectDeptList(DeptVO vo) throws Exception {		
		return deptDAO.selectDeptList(vo);
	}

	@Override
	public int selectDeptTotal(DeptVO vo) throws Exception {		
		return deptDAO.selectDeptTotal(vo);
	}

	@Override
	public int deleteDept(DeptVO vo) throws Exception {
		return deptDAO.deleteDept(vo);
	}

	@Override
	public DeptVO selectDeptDetail(String deptno) throws Exception {
		return deptDAO.selectDeptDetail(deptno);
	}

	@Override
	public int updateDept(DeptVO vo) throws Exception {
		return deptDAO.updateDept(vo);
	}
	

}
