package egovframework.example.sample.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.egovframe.rte.fdl.cmmn.EgovAbstractServiceImpl;
import org.springframework.stereotype.Service;

import egovframework.example.sample.service.CmsService;
import egovframework.example.sample.service.CmsVO;

@Service("cmsService")
public class CmsServiceImpl  extends EgovAbstractServiceImpl 
							 implements CmsService {

	@Resource(name = "cmsDAO") // DAO와 일치
	private CmsDAO cmsDAO;
	
	@Override
	public String insertCms(CmsVO vo) throws Exception {		
		return cmsDAO.insertCms(vo); //vo에 데이터가 저장되어 있는것
	}

	@Override
	public List<?> selectCmsList(CmsVO vo) throws Exception {
		return cmsDAO.selectCmsList(vo);
	}

	@Override
	public CmsVO selectCmsDetail(CmsVO vo) throws Exception {
		return cmsDAO.selectCmsDetail(vo);
	}

	@Override
	public int deleteCms(String cms_no) throws Exception {
		return cmsDAO.deleteCms(cms_no);
	}

	@Override
	public int updateCms(CmsVO vo) throws Exception {
		return cmsDAO.updateCms(vo);
	}

}
