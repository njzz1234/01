package egovframework.example.sample.service;

import java.util.List;

public interface CmsService {
	
	// public 생략가능 // 넘어온 값 받는 것
	String insertCms(CmsVO vo) throws Exception;
	List<?> selectCmsList(CmsVO vo) throws Exception;
	CmsVO selectCmsDetail(CmsVO vo) throws Exception;
	int deleteCms(String cms_no) throws Exception;
	int updateCms(CmsVO vo) throws Exception;
	
		
	

}
