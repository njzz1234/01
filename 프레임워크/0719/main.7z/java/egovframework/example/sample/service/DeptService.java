package egovframework.example.sample.service;

import java.util.List;

public interface DeptService { // 추상화 (명세처리) - 데이터베이스 연동관계에서만
	
	// 성공 : null 
	public String insertDept(DeptVO vo) throws Exception; // 저장처리를 위한 메소드
	public List<?> selectDeptList(DeptVO vo) throws Exception; //List import java.util
	//          ? = 데이터에대한 타입을 적는 공간인데 ? 는 int String 상관 없음
	// 그 다음 Impl 파일 쓰기
	public int selectDeptTotal(DeptVO vo) throws Exception;
	public int deleteDept(DeptVO vo) throws Exception;
	public DeptVO selectDeptDetail(String deptno) throws Exception;
	public int updateDept(DeptVO vo) throws Exception;

}
