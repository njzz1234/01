package egovframework.example.sample.service.impl;

import java.util.List;

import org.egovframe.rte.psl.dataaccess.EgovAbstractDAO;
import org.springframework.stereotype.Repository;

import egovframework.example.sample.service.CmsVO;
import egovframework.example.sample.service.SampleDefaultVO;

@Repository("cmsDAO")
public class CmsDAO extends EgovAbstractDAO{

	public String insertCms(CmsVO vo) {
		return (String) insert("cmsDAO.insertCms",vo);
	}

	public int deleteCms(String cms_no) {
		// TODO Auto-generated method stub
		return delete("cmsDAO.deleteCms",cms_no);
	}

	public List<?> selectCmsList(SampleDefaultVO vo) {
		// TODO Auto-generated method stub
		return list("cmsDAO.selectCmsList",vo);
	}
}
