package egovframework.example.sample.web;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.example.sample.service.CmsService;
import egovframework.example.sample.service.CmsVO;

@Controller
public class CmsController {



	@RequestMapping("/cmsWrite.do")
	public String cmsWrite() {
		return "cms/cmsWrite";
	}	
	
	@RequestMapping("/cmsDelete.do")
	public String deleteCms(String cms_no) throws Exception {
		
		int result = cmsService.deleteCms(cms_no);
		return "redirect:/cmsList.do";
	}
	

	@RequestMapping("/cmsModify.do")
	public String selectCmsDetail(CmsVO vo,ModelMap model) throws Exception {
	
		CmsVO cmsVO = cmsService.selectCmsDetail(vo);
		model.addAttribute("vo", cmsVO);
		
		return "cms/cmsModify.jsp";
	}
}
